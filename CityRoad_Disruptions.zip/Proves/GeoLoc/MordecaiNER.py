from mordecai import Geoparser
geo = Geoparser()
print (geo.geoparse("Retencions a la B-23, Barcelona."))