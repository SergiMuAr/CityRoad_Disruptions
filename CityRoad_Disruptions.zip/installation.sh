#!/bin/bash

sudo apt -y install python3-pip
sudo pip3 install tweepy
sudo pip3 install kafka
sudo pip3 install nltk
sudo pip3 install pandas
sudo pip3 install sklearn
sudo pip3 install unidecode
sudo pip3 install googlemaps
sudo pip3 install gmplot

#The user needs gather all necessary api-keys.

